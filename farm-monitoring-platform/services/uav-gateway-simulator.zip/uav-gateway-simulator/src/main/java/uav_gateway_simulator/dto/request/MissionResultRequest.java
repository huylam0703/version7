package uav_gateway_simulator.dto.request;

import java.util.List;
import java.util.UUID;

public record MissionResultRequest(
        UUID executionId,
        List<MissionNodeResultRequest> results,
        Boolean completed,
        UUID instanceId,
        Long recoveryGeneration
) {
    public MissionResultRequest(
            UUID executionId,
            List<MissionNodeResultRequest> results,
            Boolean completed
    ) {
        this(
                executionId,
                results,
                completed,
                null,
                null
        );
    }
}